# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['instrumentools']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.0,<8.0',
 'matplotlib>=3.1.2,<4.0.0',
 'ncempy>=1.5.0,<2.0.0',
 'numpy>=1.17.4,<2.0.0',
 'pandas>=0.25.3,<0.26.0',
 'scikit-image>=0.16.2,<0.17.0',
 'seaborn',
 'tqdm>=4.40.2,<5.0.0',
 'xlrd>=1.0.0,<2.0.0']

entry_points = \
{'console_scripts': ['cac_analysis = CAC.cli:cac_graphing',
                     'tem_analysis = TEM.cli:main',
                     'thermal_analysis = thermal_analysis.cli:main']}

setup_kwargs = {
    'name': 'instrumentools',
    'version': '0.2.0',
    'description': 'Data processing and plotting scripts for chemistry workflows',
    'long_description': None,
    'author': 'Dal Williams',
    'author_email': 'dendrondal@protonmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/dendrondal/instrumentools',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
